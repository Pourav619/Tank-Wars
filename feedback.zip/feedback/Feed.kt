package com.example.navchenta_welcome

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem

import android.widget.RatingBar

class Feed : AppCompatActivity() {
    private lateinit var tvFeedback: TextView
    private lateinit var rbStars: RatingBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.feedback)

        tvFeedback = findViewById(R.id.tvFeedback)
        rbStars = findViewById(R.id.rbStars)

        rbStars.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->
            when (rating.toInt()) {
                0 -> tvFeedback.text = "Very Dissatisfied"
                1 -> tvFeedback.text = "Dissatisfied"
                2, 3 -> tvFeedback.text = "OK"
                4 -> tvFeedback.text = "Satisfied"
                5 -> tvFeedback.text = "Very Satisfied"
                else -> {
                    // Handle other cases if needed
                }
            }
        }
    }


//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        if (toggle.onOptionsItemSelected(item)) {
//            return true
//        }
//        return super.onOptionsItemSelected(item)
//    }
}
