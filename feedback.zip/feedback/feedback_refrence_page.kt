package com.example.navchenta_welcome


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class feedback_refrence_page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feedback_refrence_page)
    }
}